export const items = [
  { id: 1, type: 'sword', effect: 'damage +1' },
  { id: 2, type: 'potion', effect: 'heal +2' }
];

